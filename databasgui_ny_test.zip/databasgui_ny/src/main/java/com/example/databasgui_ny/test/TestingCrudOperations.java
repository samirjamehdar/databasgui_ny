package com.example.databasgui_ny.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Test;
import org.hibernate.cfg.Configuration;


public class TestingCrudOperations {
    @Test
    public void testCrudOperations() {
//        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
//        Session session = sessionFactory.openSession();
//        session.beginTransaction();


//        Actor actor = session.get(Actor.class, 1);  /** Här hämtar vi actor med ID 1 från databasen. */
//        System.out.println(actor.toString());

        /*
        session.update(actor);
         */
    }


}

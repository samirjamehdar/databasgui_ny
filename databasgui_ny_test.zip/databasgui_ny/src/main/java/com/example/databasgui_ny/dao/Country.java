package com.example.databasgui_ny.dao;

public class Country {

}
